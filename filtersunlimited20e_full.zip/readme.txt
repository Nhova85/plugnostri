FILTERS UNLIMITED 2.0 FULL VERSION

INSTALLATION INSTRUCTIONS

IMPORTANT: To enable your graphics program to successfully integrate Filters Unlimited, you must give the path to the relevant plug-in directory during installation. For Photoshop this is the directory "Plugins", "Plug-Ins" or something similar, depending on the program version installed. For more information please read the relevant documentation for your graphics program.

If your graphics program supports multiple plugin directories, you can install Filter Unlimited to any location you want. Please consult your graphic program manual if unsure.


SYSTEM REQUIREMENTS

Filters Unlimited is intended as a plug-in, and as such only functions with a graphics program that supports Adobe Photoshop compatible plug-ins.


DISCLAIMER

The author of this plug-in accepts no responsibility for damages resulting from its use and makes no warranty or representation, either express or implied, including but not limited to, any implied warranty of merchantability or fitness for a particular purpose. This software is provided "AS IS", and you, its user, assume all risks when using it.


CONTACT

I.C.NET Software GmbH
Michael Johannhanwahr
Robert-Bunsen-Str. 70
28357 Bremen, Germany

info@icnet.de
http://www.icnet.de


COPYRIGHT

'Filters Unlimited' is Copyright (C) 1999-2002, I.C.NET Software GmbH.
All rights reserved.
