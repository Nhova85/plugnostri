Specific presets for Lattice Composer filter.

Please visit the samples page:
http://redfieldplugins.com/SamplesTutorials.htm


Installation:

1. Install Lattice Composer plug-in first.
2. Double-click on TextPresets.reg file, and confirm the registry entries.