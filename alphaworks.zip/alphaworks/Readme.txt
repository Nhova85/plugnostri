Digital Resources by CYBIA
Copyright � 2004 S.W.Upham

Visit the website for latest updates : http://www.cybia.co.uk
For more information please e-mail : steve@cybia.co.uk

ABOUT THE SOFTWARE

Title : AlphaWorks Filter
Version : 3.0
Date : January 2004

A single Photoshop-compatible plug-in filter for quickly removing black or white values and making the region transparent. There are 6 different options for you to choose from, depending on the type of image you are working on (colour photo, mono photo, lineart). It requires the use of "Layers" so remember the effect must be applied to an image that is on a layer above the background in order for it to work.

WHAT'S NEW?

Versions 1 & 2 of AlphaWorks contained 20 individual plug-in filters, but this latest update has incorportated all the main effects into one single filter dialog with a drop-down menu for ease of use. Although there are less filters this time, you can still perform all the same effects as with previous versions.

ZIP FILE CONTENTS

Readme.txt - This text file
AlphaWorks.8bf - Plug-in filter

LICENSE AGREEMENT

These files are FREEWARE. You may install them on as many computers as you want! You may use them without any charge for creating both personal and commercial work

If you wish to host these resources on a website or include them on a CD compilation (i.e. magazine cover CD), then please contact me first for permission. All zip file contents MUST remain intact and unmodified for distribution purposes. E-mail : license@cybia.co.uk
  
While every effort has been made to ensure the compatibility and stability of these resources, no warranty is given on their use. Cybia is NOT liable for any damage or loss of data resulting in the use of these files. If they crash your system don't blame me!

All resources are Copyright � 2004 S.W.Upham. This agreement does NOT grant you any intellectual property rights in the software

SYSTEM REQUIREMENTS (PC)

Windows 95/98/ME/2000/XP
Photoshop-compatible host application

INSTALLATION

1. Unzip all the files to your chosen "Plug-Ins" folder on your hard drive
    for example ... C:\Photoshop\Plug-Ins\Cybia

2. Start your graphics program and configure it to look in that folder for extra plugins
    (not all software will require this step, please refer to the instructions given with your host)

3. Exit your program and re-start in order for your configuration settings to take effect

4. Open an image ready to edit, making sure it is in RGB mode

5. AlphaWorks should now be available from the "Filter" menu in the "Cybia" section

Please read the documentation that came with your graphics software for more information regarding the installation and use of plug-in filters. Thank you.
