PhotoSwizzle

Copyright � 2001-2003 New Virtual Research, all rights reserved

PhotoSwizzle is a set of plugin filters for Adobe Photoshop and other
graphics programs including JASC Paint Shop Pro and Corel Photo-Paint.
PhotoSwizzle is distributed free of charge for a 30 day evaluation period,
after which a license fee is required for continued use. A license can be
purchased through the NVR web site named below. See the accompanying
license agreement file LICENSE_PH.DOC or LICENSE_PH.TXT for specific
rights and privileges.

To install, simply copy all of the files with .8bf extensions to the
Photoshop or other graphics program plugin directory. This will typically
be C:\PHOTOSHP\PLUGINS or a similar directory name. The next time you start
Photoshop the filters will automatically appear in the Filter dropdown
menu as the PhotoSwizzle group. If you are already running Photoshop,
exit the program and restart it for the filters to become active. For more
specific installation instructions for Photoshop or other graphics
programs go to the NVR web site named below.

Experiment, enjoy, and check back occasionally for more information and
updates at:

	http://www.pluginfilters.com/

If you have any questions or comments, send mail to
	
	support@NewVirtualResearch.com.
