
  --------------------------------------------------------------------
  C Y B I A                                   Creative Resource Studio
  --------------------------------------------------------------------

  Visit the website for latest updates          http://www.cybia.co.uk
  For more information please e-mail                 steve@cybia.co.uk

  ------------------
  ABOUT THE SOFTWARE
  ------------------

  SCREENWORKS (standard 8bf format)

  20 plug-in filters for use with Adobe Photoshop or other compatible
  host applications. Use these to create preset screen/mesh pattern
  overlays in your work

  -----------------
  ZIP FILE CONTENTS
  -----------------

   1. Sw_agmos.8bf - Aged Mosaic filter
   2. Sw_btile.8bf - Block Tile filter
   3. Sw_bdot.8bf  - Boxed Dot filter
   4. Sw_cnvas.8bf - Canvas Mesh filter
   5. Sw_clink.8bf - Chain Link filter
   6. Sw_cknit.8bf - Close Knit filter
   7. Sw_dense.8bf - Dense Net filter
   8. Sw_dscrn.8bf - Dot Screen filter
   9. Sw_fwve.8bf  - Fabric Weave filter
  10. Sw_graph.8bf - Graph Paper filter
  11. Sw_glay.8bf  - Grid Layout filter
  12. Sw_hdot.8bf  - Hollow Dot filter
  13. Sw_laces.8bf - Lace Screen filter
  14. Sw_lgze.8bf  - Light Gauze filter
  15. Sw_grain.8bf - Mezzo Grain filter
  16. Sw_mmaze.8bf - Micro Maze filter
  17. Sw_netp.8bf  - Net Pattern filter
  18. Sw_pinh.8bf  - Pin Hole filter
  19. Sw_pshd.8bf  - Pixel Shade filter
  20. Sw_array.8bf - Point Array filter
  21. Readme.txt   - This text file
  22. Register.txt - Registration form

  -----------------
  LICENSE AGREEMENT
  -----------------

  These filters are FREEWARE. You may install them on as many 
  computers as you want! You may use them without any charge for 
  creating both personal and commercial work

  If you wish to host these resources on a website or include them on
  a CD compilation (i.e. magazine cover CD), then please contact me
  first for permission. All zip file contents MUST remain intact and
  unmodified for distribution purposes. E-mail : license@cybia.co.uk
  
  While every effort has been made to ensure the compatibility and
  stability of these resources, no warranty is given on their use.
  Cybia is NOT liable for any damage or loss of data resulting in the
  use of these filters. If they crash your system don't blame me!

  All resources are copyright � Steve Upham 1998/99 This agreement 
  does NOT grant you any intellectual property rights in the software

  -------------------
  SYSTEM REQUIREMENTS
  -------------------

  Windows 95/98, Photoshop-compatible host application

  ------------
  INSTALLATION
  ------------

  Unzip all the *.8bf files to your chosen plug-ins directory
  Please refer to your program's documentation to configure plug-ins

  ------------
  REGISTRATION
  ------------
  
  Please don't forget to send the registration form that comes with 
  this zip file. Registration is completely free and only to help
  generate some feedback about these products. Thank you

  ------------------
  ADDITIONAL CREDITS
  ------------------

  Plug-in filters created with Filter Factory (56k version)
  Zip file created with EnZip 2.60, a freeware utility by Chris Marsh

  --------------------------------------------------------------------
  C Y B I A                                   Creative Resource Studio
  --------------------------------------------------------------------