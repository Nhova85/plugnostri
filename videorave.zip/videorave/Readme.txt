

The files in this zip are Copyright 1998 by Harald Heim

You can use them for whatever you like, 
but you aren't allowed to distribute them.

Email:
harry@visca.com

PlugIn Com HQ
Free Plugins, Effects and Tools for Image and Video Editing
http://pico.i-us.com/

