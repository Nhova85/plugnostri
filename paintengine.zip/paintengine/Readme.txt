---------------------------------------------------------------------  
PaintEngine beta version 1.10 - June 9, 1998
Copyright (C) 1995-1998 Fantastic Machines.  All rights reserved.

---------------------------------------------------------------------  
Description:
 
    PaintEngine is a plug-in filter for Adobe Photoshop compatible
    plugin hosts. It is a highly configurable paint effects processor
    that works with RGB images.
   

---------------------------------------------------------------------  
File List:                       

    pe.8bf           plug-in filter module
    readme.txt       this file
    fmachine.ini     settings file

---------------------------------------------------------------------  
Installation:

    copy pe.8bf to your plug-in directory, for example 
    C:\PHOTOSHP\PLUGINS                   
    
    copy fmachine.ini to your windows directory, i.e.
    C:\WINDOWS.
    note: if you've used a previous version of PaintEngine
    and don't want to lose any parameter settings you've 
    saved, don't copy fmachine.ini.
                   
---------------------------------------------------------------------  
Info:

    Fantastic Machines
    1994 Comox Ave
    Comox, BC  Canada V9M 3M7         

E-mail: customerservice@fantasticmachines.com
Fantastic Machines Home page: 
    http://www.fantasticmachines.com
    
---------------------------------------------------------------------  
Notes: 
    
   PaintEngine works with the following: 
       Photoshop 3.0.5 or higher
       Paint Shop Pro 4 & 5
       SPG ColorWorks 3
   
---------------------------------------------------------------------
Disclaimer of Warranty

THIS SOFTWARE AND THE ACCOMPANYING FILES ARE PROVIDED AS IS WITHOUT 
WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED. IN NO EVENT SHALL 
FANTASTIC MACHINES BE LIABLE FOR ANY DAMAGES WHATSOEVER.
