
  --------------------------------------------------------------------
  C Y B I A                                   Creative Resource Studio
  --------------------------------------------------------------------

  Visit the website for latest updates          http://www.cybia.co.uk
  For more information please e-mail                 steve@cybia.co.uk

  ------------------
  ABOUT THE SOFTWARE
  ------------------

  EMBOSSWORKS (deluxe 8bf format)

  20 plug-in filters for use with Adobe Photoshop or other compatible
  host applications. Each of these creates an emboss/offset effect

  -----------------
  ZIP FILE CONTENTS
  -----------------

   1. Em_foil.8bf  - Bright Foil filter
   2. Em_grey.8bf  - Classic Grey filter
   3. Em_tint.8bf  - Colour Tint filter
   4. Em_neon.8bf  - Dark Neon filter
   5. Em_gradh.8bf - Gradient H filter
   6. Em_gradr.8bf - Gradient R filter
   7. Em_gradv.8bf - Gradient V filter
   8. Em_hard.8bf  - Hard Glass filter
   9. Em_heavy.8bf - Heavy Metal filter
  10. Em_ice.8bf   - Ice White filter
  11. Em_lead.8bf  - Leaded Glass filter
  12. Em_light.8bf - Light Metal filter
  13. Em_monby.8bf - Mono BY filter
  14. Em_mongm.8bf - Mono GM filter
  15. Em_monrc.8bf - Mono RC filter
  16. Em_burn.8bf  - Radial Burn filter
  17. Em_sandb.8bf - Sand Blast filter
  18. Em_silno.8bf - Silver Noise filter
  19. Em_soft.8bf  - Soft Glass filter
  20. Em_tind.8bf  - Tin Detail filter
  21. Readme.txt   - This text file
  22. Register.txt - Registration form

  -----------------
  LICENSE AGREEMENT
  -----------------

  These filters are FREEWARE. You may install them on as many 
  computers as you want! You may use them without any charge for 
  creating both personal and commercial work

  If you wish to host these resources on a website or include them on
  a CD compilation (i.e. magazine cover CD), then please contact me
  first for permission. All zip file contents MUST remain intact and
  unmodified for distribution purposes. E-mail : license@cybia.co.uk
  
  While every effort has been made to ensure the compatibility and
  stability of these resources, no warranty is given on their use.
  Cybia is NOT liable for any damage or loss of data resulting in the
  use of these filters. If they crash your system don't blame me!

  All resources are copyright � Steve Upham 2000. This agreement 
  does NOT grant you any intellectual property rights in the software

  -------------------
  SYSTEM REQUIREMENTS
  -------------------

  Windows 95/98, Photoshop-compatible host application

  ------------
  INSTALLATION
  ------------

  Unzip all the *.8bf files to your chosen plug-ins directory
  Please refer to your program's documentation to configure plug-ins

  ------------
  REGISTRATION
  ------------
  
  Please don't forget to send the registration form that comes with 
  this zip file. Registration is completely free and only to help
  generate some feedback about these products. Thank you

  ------------------
  ADDITIONAL CREDITS
  ------------------

  Plug-in filters created with ATS Graphics Filter Formula 1.1
  Filter Formula layout template (tpl) by Harald Heim
  Zip file created with EnZip 3.0, a freeware utility by Chris Marsh

  --------------------------------------------------------------------
  C Y B I A                                   Creative Resource Studio
  --------------------------------------------------------------------