    *****CRESCENT MOON SOFTWARE AUSTRALIA*****

            ***PHOTOSHOP PLUG IN'S***

Thanks for taking the time to try out our plugin's
for Adobe Photoshop and compatable packages.


                 ***INSTALLATION***
Installation should be pretty easy, just place the (un-zipped)
files in your plug-in directory and next time you start your
graphics program(Photoshop for most of us) these plug-in's
should appear along with all the others.

OK now the legal bit.....

                **** LEGAL NOTICE ****
NOTE: This software is provided as-is, and no direction or
recommendation as to its usage should be implied or infered.
Any damage caused by its use is entirely at the users risk.

Good that's over, now what to do if it aint working.... 

                   **** SUPPORT ****
Any problems or suggestions can be reported to:

Crescent Moon Software Australia
9 Havelock Street
St.Kilda
Victoria 3182
Australia.

Finally we try and get food on the table.....

              ***** PAYMENT & INCENTIVE *****
These plug-in's are provided as Shareware. This means if you
use, one or more of them after you have tried them we'd want
you to send us the shareware fee of US$25.00. To encourage
you to send the US$25.00 we will send you (as available) 
8 more plug-in's free of charge when you do so(dont forget 
to send us your address!). This is our way of saying thanks 
for registering with us. You also get on our (infrequent) 
mailing list about new products(like other plug-ins, fonts,
programs etc..).

So in review:
1. Place the plug-in in your plug-in directory.
2. Send the US$25.00 to the address above.
3. Wait for your 8 free plug-ins.

NOTE: Fast access to the free plug-ins by sending us your 
      email address!!

We hope you enjoy this stuff, have fun!

regards,

Crescent Moon Software Australia
 







