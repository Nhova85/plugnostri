HALFTONE FILTERS by Tim Lister
===============

This package contains:
---------------------
* this document (.txt)
* 8 haltone filters (.8bf)
* the Filter Factory source files (.afs)

Algorithms are taken from:
-------------------------
"Digital Halftoning"
Robert Ulichney
MIT Press
ISBN 0-262-21009-6

"Digital halftoning, also referred to as spatial dithering,
is the method of rendering the illusion of continuous-tone
pictures on displays that are capable of producing only
binary picture elements."
    - Ulichney

Halftoning is most commonly used for producing images to be
printed in Black & White, when no colour or greyscales are
available to that print job.

There are also other good reasons for using halftoned images:

* File size - a halftoned image is 1bit colour depth, making
  the file 24 times smaller than a 24bit colour depth image.

* Visual effects - can be a very striking form of display,
  used tastefully.

* Masks & Alpha-channels - interesting effects are possible.


The Filters:
-----------

Diagonal 2x2: a 2x2 threshhold matrix in a diamond shape.
		3 grey-levels.

Diagonal 4x4: a 4x4 threshhold matrix in a diamond shape.
		9 grey-levels.

Dither 2x2:	a 2x2 threshhold matrix in a square shape.
		5 grey-levels.

Dither 4x4:	a 4x4 threshhold matrix in a square shape.
		17 grey-levels.

Hex order 1:	a 2x2 threshhold matrix in a hexagon shape.
		4 grey-levels.

Hex order 2:	a 3x3 threshhold matrix in a hexagon shape.
		10 grey-levels.

Random Noise: random threshhold for every pixel.
		2 grey-levels.

Spiral Dot 4x4: a 4x4 threshold matrix in a spiral shape.
		17 grey-levels.

Notes:
-----
* i added a "map" function to every filter in this set,
so that you can force the low intensity pixels to black,
the high intensity pixels to white, and dither the mid-range
pixel intensities.

* the hexagon based filters are slightly distorted by my
slack maths, where i just put the threshhold values
in a square matrix, and filled the empty cells with
repetitions of other cells, on the assumption that the
distorted hexagons would tile the plane.

* almost any set of distributed threshholds will produce
some kind of dithering, many of them quite effective.
which you should use probably depends on how many grey
levels you wish to recognise and how "good" the result
looks - yes, it's subjective.

enjoy,
      tal
---------

enquiries & remarks: tal@maxtal.com.au
visit my homesite: http://www.maxtal.com.au/~tal
