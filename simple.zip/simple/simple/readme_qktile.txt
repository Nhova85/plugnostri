Readme.txt file for Simple Filters Quicktile.

Installation Instructions
--------------------------------------------
Unzip the file qktile.8bf and place it in
your plugin directory.

Note this filter does not require any .dll
files.

See the help section on 
http://www.cateran.btinternet.co.uk/simple/
if you have any difficulties

The Thanks Section
----------------------------------------------

Hey, I finally wrote a Filtermeister filter
I wanted to show other people, I need to thank
a few folk 

- Alex Hunter and all the guys in the 
Filtermeister mailing list for all the
amazing help they give filter authors.

See http://www.filtermeister.com

- The folks on the PSP interactive Zone
website for their support and encouragement
in testing this filter. I got the idea for 
this filter from an academic website about
tiling and discussed it with the folk on PSPIZ.
right from the off my mail box was 'pinging' 
(hey Keya!) with people spending time helping 
me.

See http://www.pspiz.com

- Oh and a quick hello to the ladies on the 
PIrc message board. I've not forgotten about you,
in fact after I write this I'm coming over to 
pester you to let me know this works OK on PI.

See: http://pub45.ezboard.com/bpirc67276

- Last but not least all the folks who took the
time to email me about the other filters I wrote
and thank me. I love you all.


Now the heavy legal stuff.
------------------------------------------------
This filter is copyright Alexander Blair 

I do not write filters commercially, I never 
give permission for any of my filters to be sold 
by others. 

I DO retain copyright (which lets me refuse the 
offers from folk who would sell them) and I so
I retain distribution rights.

This means that no one else should place this 
filter on their own website.

Let me emphasise that. No one else has permission 
to distribute this filter. It should not be placed
on any other web site, yahoo message board file 
area, or sent out on email. A link to my site 
will let anyone get the filter without charge but
also lets me know how many downloads there have 
been and lets folk always see the latest version.


Which leads us to the no thanks whatsoever section.
--------------------------------------------------
To the folks on the ezboard 'eclectic' message
boards, because of you I nearly didn't release 
this filter.

Here is why:

As I said above, this was tested by the folks on 
the PSPIZ site, I gave them access to an early 
test version it wasn't meant for distribution 
and it was clear that this was so. But I noticed 
in my referral logs a link coming from another site 
to the test version file and found that someone had 
placed a link on another message board.

I renamed the test version file. 

I checked back on this 'eclectic' message board a 
few days later. One of the users of this message 
board, noticing the link no longer worked, put the
test version of my filter on their own website 
and posted a link to it on this message board.

I left a brief message stating 'Please remove my 
copyright software from your website'. (Those of you
who know me might be suspicious that I used such 
temperate language, but that was all I said.)

It was enough to unleash a fury of comments about 
'coming here upsetting people'. that they weren't 
'corporate lawyers' and so 'didn't know they couldn't
put other peoples work on their websites'... 

I guess we've all heard the arguments.

I was banned from posting on that board. Although 
my own two short, polite messages were deleted 
they didn't have the decency to leave the matter 
and many others on the message board had a fun 
time speculating wildly on my character. Ironically 
accusing me of just causing trouble and not staying 
to defend myself (this from the person who banned 
me - huh??).

It always leaves a sour taste in my mouth dealing 
with such shabby people. My wife thinks I am mad to
let such people get to me or let it prevent
me sharing the filters I write (which I enjoy)...
but I think that's the important thing. It does
discourage creators of work to be so treated.

How keen will a tutorial writer be to write another
tutorial when they find their tutorial has 
reappeared on another site intact but with a 
different 'author' at the bottom? Same as for 
tubes / masks / clip art / websets/ whatever.

When we treat this freely shared work like the people
on the eclectic board we discourage people to create
and share any more and we all loose from that.

So anyway I have a done a deal with myself. I'll
keep writing filters with the aim of providing
helpful and free tools to the graphics community
on the net as long as I get to complain when I am
pirated. I cant even promise to be nice about it.

And you can do a deal too, If you enjoy this filter
maybe you should have a moan the next time you see 
something being pirated. Maybe you should be nice 
about it though - at least at first.

Cheers, Sandy.




