The Sinedots II presets in this .cfg file were submitted by members of the PSP_Pluggers@yahoogroups.com
email list.  The following creators contributed to this file -

Sally Beacham, dizzaster@cybertours.com, www.dizteq.com
S.Curry, scurry@nyc.rr.com ,http://www.sjcreations.com/graphics.htm  
Cherokee, cheroke@iland.net,  http://www.geocities.com/nashville/opry/3307
Di, http://members.tripod.co.uk/Dis_Delights/
Lora-Ly
T-Storm,t_storm@maxleft.com,  http://www.stormingn2psp.com/index.html
Gary W. Vanderbur, Vandy@nc.rr.com
Patti Wavinak, patti@moonsdesigns.com - http://moonsdesigns.com/tutorials/


