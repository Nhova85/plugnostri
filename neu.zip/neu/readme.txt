Copyright � 1998 Alexander Blair. 

Check out http://www.btinternet.com/~cateran/neu/
for updates and more filters.
                             
This filter should only be distributed with permission 
so if you downloaded it from anywhere apart from
the above website please let me know. 

Alexander Blair - email: cateran@btinternet.com

If you need help installing this filter then please read the
help area at http://www.btinternet.com/~cateran/neu/
