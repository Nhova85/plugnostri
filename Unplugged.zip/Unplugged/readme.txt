 Unplugged
-===========-=-- -
Plugins for PhotoShop, Premiere, Paint Shop Pro, PhotoPaint and many others.

Copyright 1997/1998/1999 Martijn W. van der Lee.

  E-Mail: unplugged@v-d-l.com
Internet: http://www.v-d-l.com
   Snail: M.W. van der Lee
          Meentweg 36
          1405 JB   Bussum
          Netherlands


 Copyright
-===============-=-- -
Read the file "Legal.txt" included with the archive to learn about the
copyright issues. Suffice to know that no exchange of any kind may be
made when duplicating the archive and only the original archive may
be copied. Better yet; just give out the adress of my site :)


 Installation
-==============-=-- -
By the time you read this you will already have installed the filters.
They should be installed in a directory recognized by your graphics
application. Please refer to your application's manual or the
installation help in this text file

If you use a version of Photoshop before 4.0 or any other application
which will not recursivly scan for plugins in subdirectories, you
should copy all the files from the subdirectories into the plugin
directory.

Also note that the directory names are Windows '95/NT format.
The filenames are DOS-format though.

You may need to have the file "MSVCRT10.DLL" loaded in the
Windows/System directory in order to use these plugins.
This file is freely available on the internet.


 Compatibility & Installation
-==============================-=-- -
Check http://www.v-d-l.com for an up-to-date compatibility list and
installation instructions.