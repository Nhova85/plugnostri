Adrenaline Snowflakes v1.01
===========================

Copyright �1999-2002 Martijn W. van der Lee/VanDerLee.
All Rights Reserved.

Legal agreement
Martijn van der Lee permits you use Snowflakes (Software) conditioned on your acceptance of this agreement. Use of this Software will be taken to mean acceptance of this agreement, so please read the following terms carefully before you use the Software.

1. Copyright and permission for use
Martijn van der Lee grants you as an individual the right to use the Software on only one computer at any single time. The ownership and copyright of the Program belongs to Martijn van der Lee.

2. Prohibitions and restrictions
You may not reverse-compile, disassemble, reverse-engineer, or use any other method to convert the Software into a human-readable form, nor may you allow another person to do so. The Software may not be duplicated, corrected, modified, lent, leased, sold, distributed, licensed or disposed of in any other way in part or in whole if money or other means of payment or restitution are involved. The creation of derivative works based on the content of the Software is also prohibited. Your rights regarding the Software may be transferred to a third party only if this is done for non-commercial purposes and if the Software and all associated documentation including this agreement are included, and if the third party accepts this agreement.

3. Limitations of Liability
The Software was developed at, and is copyrighted by, Martijn van der Lee. The Software is offered "AS IS" and Martijn van der Lee makes no warranty as to its use or performance.
MARTIJN VAN DER LEE AND ITS SUPPLIERS DO NOT AND CANNOT WARRANT THE PERFORMANCE OR RESULTS YOU MAY OBTAIN BY USING THE SOFTWARE OR DOCUMENTATION. MARTIJN VAN DER LEE AND ITS SUPPLIERS MAKE NO WARRANTIES, EXPRESS OR IMPLIED, AS TO NON INFRINGEMENT OF THIRD PARTY RIGHTS, MERCHANTABILITY, OR FITNESS FOR ANY PARTICULAR PURPOSE. IN NO EVENT WILL MARTIJN VAN DER LEE OR ITS SUPPLIERS BE LIABLE TO YOU FOR ANY CONSEQUENTIAL, INCIDENTAL OR SPECIAL DAMAGES, INCLUDING ANY LOST PROFITS OR LOST SAVINGS, EVEN IF MARTIJN VAN DER LEE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, OR FOR ANY CLAIM BY ANY THIRD PARTY.