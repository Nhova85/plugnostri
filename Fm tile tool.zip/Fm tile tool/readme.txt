---------------------------------------------------------
FM Tile Tools version 1.1 - October 3, 1997
Copyright (C) 1995-1997 Fantastic Machines.  
All rights reserved.


---------------------------------------------------------

Thank you for trying FM Tile Tools!

Tile Tools is a set of Adobe Photoshop compatible
plugin filters especially designed for creating tileable
images and textures. 
These plugins will work with any host image editing 
package that can use 32-bit Photoshop format plugins
under Windows 95. FM Tile Tools has been tested with the 
following packages:

Adobe Photoshop 3.0.5
JASC Paint Shop Pro 4.12
SPG ColorWorks:WEB 3.002
Fractal Design/MetaCreations Detailer 1.02
Equilibrium DeBabelizer Pro 4.0


After installation, The filters will be available 
in the host program's Filter menu under the heading 
"FM Tile Tools".

Seven of the 21 filters are unlocked and fully usable. 
The following filters are available immediately:

    Blend Emboss        Seamless Tile
    Image Roll          Blob Carve 1
    Bricks              Circular Collage
    Warp    
    
To obtain a password  that will unlock the remaining 
filters, please call 1-888-225-6622 (toll free in 
North America) with your Visa or Mastercard number. 
Outside of North America, call 1-250-339-7876. Please 
call between 8am and 7pm (pacific time), monday 
through saturday. The cost of FM Tile Tools is (US)$29.

Orders may also be placed by e-mail or postal delivery -
see the file ordering.txt for more information.

---------------------------------------------------------
Company Info

Address:

    Fantastic Machines
    1994 Comox Ave
    Comox, BC  Canada V9M 3M7         

Fax:  1-250-339-5855 

Orders: 1-888-225-6622

E-mail: gschorno@mars.ark.com

Fantastic Machines Home page: 
    http://mars.ark.com/~gschorno/machine/
    
---------------------------------------------------------
     
